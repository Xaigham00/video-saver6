package com.example.vdl

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.lang.reflect.InvocationTargetException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {

    private lateinit var urlInput: EditText
    private lateinit var videoBtn: Button
    private lateinit var audioBtn: Button
    private lateinit var updateBtn: Button
    private lateinit var spinner: ProgressBar
    private lateinit var status: TextView

    private val worker = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val ui = Handler(Looper.getMainLooper())
    private val initLock = Any()

    @Volatile private var ready = false
    @Volatile private var watchDir: File? = null

    // Shows how many MB have been downloaded so far (updates every second).
    private val ticker = object : Runnable {
        override fun run() {
            val d = watchDir ?: return
            val bytes = d.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            status.text = "Downloading… " + formatSize(bytes)
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    // ---------- UI ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun params(top: Int = 12): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Paste a link, or use Share → Video Saver from any app."
            textSize = 16f
        }, params(0))

        urlInput = EditText(this).apply {
            hint = "https://…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 3
        }
        root.addView(urlInput, params(16))

        videoBtn = Button(this).apply {
            text = "Download video"
            setOnClickListener { startDownload(audioOnly = false) }
        }
        root.addView(videoBtn, params(16))

        audioBtn = Button(this).apply {
            text = "Download audio (MP3)"
            setOnClickListener { startDownload(audioOnly = true) }
        }
        root.addView(audioBtn, params(8))

        updateBtn = Button(this).apply {
            text = "Update downloader engine"
            setOnClickListener { updateEngine() }
        }
        root.addView(updateBtn, params(8))

        spinner = ProgressBar(this).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        root.addView(spinner, params(16))

        status = TextView(this).apply {
            textSize = 15f
            setTextIsSelectable(true)
        }
        root.addView(status, params(16))

        root.addView(TextView(this).apply {
            text = "Keep the app open while it downloads. Videos are saved in Movies/VideoSaver, " +
                "audio in Music/VideoSaver. If a site stops working, tap \"Update downloader engine\". " +
                "Only download content you own or have permission to save."
            textSize = 13f
            alpha = 0.7f
        }, params(24))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun setStatus(msg: String) {
        runOnUiThread { status.text = msg }
    }

    private fun setBusy(b: Boolean) {
        runOnUiThread {
            videoBtn.isEnabled = !b
            audioBtn.isEnabled = !b
            updateBtn.isEnabled = !b
            spinner.visibility = if (b) View.VISIBLE else View.GONE
        }
    }

    // ---------- Share intent ----------

    private fun extractUrl(text: String?): String? =
        text?.let { Regex("https?://[^\\s]+").find(it)?.value }

    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val shared = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val url = extractUrl(shared)
        if (url == null) {
            setStatus("No link found in the shared text.")
            return
        }
        urlInput.setText(url)
        startDownload(audioOnly = false)
    }

    // ---------- Engine ----------

    private fun ensureReady() {
        if (ready) return
        synchronized(initLock) {
            if (ready) return
            setStatus("Preparing downloader (first start takes a little while)…")
            YoutubeDL.getInstance().init(application)
            FFmpeg.getInstance().init(application)
            ready = true
        }
    }

    private fun startDownload(audioOnly: Boolean) {
        val url = extractUrl(urlInput.text.toString())
        if (url == null) {
            setStatus("Paste or share a valid link first.")
            return
        }
        if (!busy.compareAndSet(false, true)) return
        setBusy(true)
        setStatus("Starting…")

        worker.execute {
            val dir = File(cacheDir, "dl/" + System.currentTimeMillis()).apply { mkdirs() }
            try {
                ensureReady()

                val req = YoutubeDLRequest(url)
                req.addOption("-o", dir.absolutePath + "/%(title).80s.%(ext)s")
                req.addOption("--no-mtime")
                req.addOption("--no-playlist")
                if (audioOnly) {
                    req.addOption("-f", "ba/b")
                    req.addOption("-x")
                    req.addOption("--audio-format", "mp3")
                } else {
                    req.addOption("-f", "bv*+ba/b")
                    req.addOption("-S", "res:1080,ext:mp4:m4a")
                    req.addOption("--merge-output-format", "mp4")
                }

                watchDir = dir
                ui.post(ticker)

                YoutubeDL.getInstance().execute(req)

                watchDir = null
                ui.removeCallbacks(ticker)

                val files = dir.listFiles()
                    ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && !it.name.endsWith(".temp") }
                    .orEmpty()
                if (files.isEmpty()) error("The download finished but no file was produced.")

                val saved = files.map { saveToPublic(it) }
                ui.post { status.text = "Saved ✓\n" + saved.joinToString("\n") }
            } catch (e: Throwable) {
                watchDir = null
                ui.removeCallbacks(ticker)
                ui.post { status.text = "Failed:\n" + shortError(e) }
            } finally {
                dir.deleteRecursively()
                busy.set(false)
                setBusy(false)
            }
        }
    }

    private fun updateEngine() {
        if (!busy.compareAndSet(false, true)) return
        setBusy(true)
        setStatus("Updating downloader engine…")
        worker.execute {
            try {
                ensureReady()
                val result = callUpdate()
                ui.post { status.text = "Update finished: $result" }
            } catch (e: Throwable) {
                ui.post { status.text = "Update failed:\n" + shortError(e) }
            } finally {
                busy.set(false)
                setBusy(false)
            }
        }
    }

    // Uses reflection so the app compiles whichever way the library names its update channel.
    private fun callUpdate(): String {
        val yt = YoutubeDL.getInstance()
        val method = yt.javaClass.methods.first { it.name == "updateYoutubeDL" && it.parameterTypes.size == 2 }
        val channel = findStableChannel(method.parameterTypes[1])
        return method.invoke(yt, application, channel)?.toString() ?: "done"
    }

    private fun findStableChannel(type: Class<*>): Any {
        type.enumConstants?.firstOrNull { (it as Enum<*>).name == "STABLE" }?.let { return it }
        for (name in listOf("STABLE", "_STABLE")) {
            try {
                val v = type.getField(name).get(null)
                if (v != null) return v
            } catch (_: Throwable) {
            }
        }
        type.declaredClasses.firstOrNull { it.simpleName == "STABLE" }?.let {
            val v = it.getField("INSTANCE").get(null)
            if (v != null) return v
        }
        error("Could not find the STABLE update channel.")
    }

    // ---------- Saving ----------

    private fun saveToPublic(f: File): String {
        val mime = when (f.extension.lowercase()) {
            "mp4", "m4v" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            "mov" -> "video/quicktime"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "opus", "ogg" -> "audio/ogg"
            else -> "application/octet-stream"
        }
        val (collection, folder) = when {
            mime.startsWith("video/") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/VideoSaver")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(collection, values) ?: error("Could not create the output file.")
        val out = contentResolver.openOutputStream(uri) ?: error("Could not open the output file.")
        out.use { o -> f.inputStream().use { it.copyTo(o) } }
        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        return "$folder/VideoSaver/${f.name}"
    }

    // ---------- Helpers ----------

    private fun shortError(e: Throwable): String {
        val t = (e as? InvocationTargetException)?.targetException ?: e
        val m = t.message ?: t.toString()
        val line = m.lines().lastOrNull { it.contains("ERROR") }
        return (line ?: m.takeLast(400)).trim()
    }

    private fun formatSize(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb < 1) "${bytes / 1024} KB" else String.format("%.1f MB", mb)
    }
}
